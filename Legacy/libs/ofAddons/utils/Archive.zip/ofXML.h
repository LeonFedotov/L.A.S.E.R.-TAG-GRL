#ifndef __OFXML__
#define __OFXML__

#include "ofMain.h"
#include <string.h>
#include "xmlParser.h"

class ofXML{

	public:
		ofXML();
		
		void setVerbose(bool _verbose);				
		
		void init(string mainTag);		
		void initFromFile(string xmlFile, string mainTag);
		void saveFile(string  xmlFile);
		
		void clearTagContents(string tag);
		void removeTag(string  tag);

		int 	getValue(string  tag, int  	 defaultValue);
		float 	getValue(string  tag, float  defaultValue);
		string 	getValue(string  tag, string defaultValue);

		void setValue(string  tag, float  valueAsfloat);
		void setValue(string  tag, int    valueAsInt);
		void setValue(string  tag, string valueAsString);
		
	private:
		 XMLNode parseTag(string tag);
		 bool checkErrors();
		 string cleanTag(string tag);
		 
		 XMLNode xMainNode;
		 bool mainTagSet;
		 bool readingEnabled;
		 bool verbose;

};

#endif